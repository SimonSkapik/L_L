<?php
register_nav_menus( array(
	'menu_left' => 'Main Menu Left',
	'menu_right' => 'Main Menu Right'));
?> 